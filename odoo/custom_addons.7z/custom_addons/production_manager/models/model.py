from odoo import models, fields, api, _
from odoo.exceptions import UserError

class ClassName(models.Model):
    _name = "module_name"
    _description = "module_description"
